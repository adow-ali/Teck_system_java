// GLOBAL VARIABLES

const CardContainer = document.querySelector(".card-container");
let cartDetails;
let cartAddedproducts = [];

// FUNCTION FOR FETCHING THE API'S DATA

const handleBooksApi = () => {
  fetch("/ApiData/data.json")
    .then((res) => res.json())
    .then((data) => displayBooksCard(data));
};

// CALL FUNCTION
handleBooksApi();

// FUNCTION FOR DISPLAYING BOOK CARDS DATA

const displayBooksCard = (data) => {
  cartDetails = data;
  data.forEach((elem) => {
    const div = document.createElement("div");
    const singleCard = document.createElement("div");
    div.classList.add("col-md-3");
    div.classList.add("book-card");
    div.appendChild(singleCard);
    singleCard.innerHTML = `
              <img src="${elem?.img}" alt="" />
              <h5>${elem?.name}</h5>
              <p class="mb-0">${elem?.Author}, ${elem?.date}</p>
              <p>Price $${elem?.price}.00</p>
              <button onclick="handleAddToCart(${elem?.id})" class="add-to-cart-btn">
                Add to cart
              </button>
          `;
    CardContainer.appendChild(div);
  });
};

// CALL FUNCTION
displayBooksCard();

// HANDLE ADD TO CART FUNCTION

function handleAddToCart(id) {
  // SELECTED THE GLOBAL VARIABLE
  const cartDetail = cartDetails;
  // FINDING THE MATCHED PRODUCT THROUGH PRODUCT ID
  const filterCartDetail = cartDetail.find(
    (addProduct) => addProduct?.id == id
  );

  // USING SHIFT TO REMOVE FIRST INDEX FROM GLOBAL ARRAY
  cartAddedproducts.shift();
  // PUSHING ADDED PRODUCT DATA TO THE GLOBAL ARRAY
  cartAddedproducts.push(filterCartDetail);

  // SELECTED THE DIV IT HAS CLASS NAME CALLED ADDED-PRODUCTS
  const addedProducts = document.querySelector(".added-products");

  // LOOPING THE DATA FROM GLOBAL ARRAY
  cartAddedproducts.forEach((addedProduct) => {
    // CREATING A DIV
    const div = document.createElement("div");
    // ADDED CLASS NAME TO THE CREATED DIV
    div.classList.add("added-product");
    // WRITING HTML TAGS DYNAMICALLY AND PASSING VALUES FROM LOOP DATA
    div.innerHTML = `
          <img src=${addedProduct?.img} alt=""/>
          <div>
              <h6>${addedProduct?.name}</h6>
              <p>$${addedProduct?.price}.00</p>
          </div>
      `;
    // ADDED THE CREATED DIV TO SELECTED DIV
    addedProducts.appendChild(div);
  });
}

// HANDLE REMOVE FUNCTION TO REMOVE ADDED PRODUCTS CARTS

function handleRemoveProductToCart() {
  // SELECTED THE DIV IT HAS CLASS NAME CALLED ADDED-PRODUCTS
  const addedProducts = document.querySelector(".added-products");
  // CLEARING THE CHILD CONTENT OR HTML TAGS FROM SELECTED DIV
  addedProducts.innerHTML = "";
}
